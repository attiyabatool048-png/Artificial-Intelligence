# 🤖 Jarvis Voice Assistant (Python AI Assistant)

A Python-based **Voice-Controlled AI Assistant** that listens to your commands and performs tasks like opening websites, telling time, and searching the web.

This project is inspired by **JARVIS from Iron Man** and demonstrates **speech recognition + automation using Python**.

---

# 🚀 Features

✔ Voice command recognition 🎙️
✔ Text-to-speech response 🔊
✔ Opens websites (YouTube, Google)
✔ Performs Google search
✔ Tells current time
✔ Continuous listening mode

---

# 🛠 Technologies Used

* Python
* SpeechRecognition
* Pyttsx3 (Text-to-Speech)
* Webbrowser
* Datetime

---

# 📂 Project Structure

```id="j8m2zx"
jarvis-voice-assistant
│
├── main.py
└── README.md
```

👉 Rename your file to **main.py** for clean structure.

---

# ⚙️ Installation

1️⃣ Install Python 3.x

2️⃣ Install required libraries:

```bash id="p7n3kl"
pip install SpeechRecognition pyttsx3 pyaudio
```

⚠️ If `pyaudio` fails:

* Windows users may need pre-built wheels
* Or use:

```bash id="x3k9pl"
pip install pipwin
pipwin install pyaudio
```

---

# ▶️ How to Run

```bash id="k9p2zl"
git clone https://github.com/ravigautam7739/jarvis-voice-assistant.git
cd jarvis-voice-assistant
python main.py
```

---

# 🧠 How It Works

1. Microphone listens for user voice
2. Speech is converted to text using Google API
3. Command is processed
4. Based on command:

   * Opens websites
   * Searches Google
   * Tells time
5. Response is spoken using text-to-speech

---

# 💻 Example Commands

```id="v8p2wl"
"Open YouTube"
"Open Google"
"What is the time"
"Search Python tutorials"
"Stop"
```

---

# 💻 Example Output

```id="m3n9pt"
Listening...

You said: open youtube

Jarvis: Opening YouTube
```

---

# 🎯 Use Cases

* Voice-controlled automation
* Personal assistant systems
* Smart home projects
* AI learning projects
* Beginner NLP applications

---

# ⚠️ Notes

* Requires microphone access
* Internet required for speech recognition
* Works best in low-noise environment
* May not recognize all accents perfectly

---

# 🔮 Future Improvements

* Add more commands (apps, system control)
* Integrate ChatGPT / AI responses
* GUI interface
* Wake word detection ("Hey Jarvis")
* Smart home integration

---

# ⭐ Support

If you found this project useful, give it a **star ⭐**.

---

# 📱 Follow for More Projects

I regularly share **Python, AI, and automation projects**.

Stay tuned 🚀
